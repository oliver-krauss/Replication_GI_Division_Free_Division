/*WBL 17 May 2018 "$Revision: 1.5 $" */

//WBL  8 Jun 2018 for use with newly created t_log2.c
//WBL 26 May 2018 for use with log2

//Compile: gcc -c -g main.c; gcc -o main gi_log2.o main.o -lm

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
//#include <ctype.h>
//#include <unistd.h>
//#include <string.h>

#include "t_log2.c"
//#include "t_test.c"
//#include "e_sqrt.c"

int t_log2_idx; //not in use but keep linker happy

//#define sqrt __ieee754_sqrt
//double __ieee754_sqrt (const double x);
#define log2 gi_log2
//double table_ieee754_log2 (const double x);
double gi_log2 (const double x);

double input;

int main(int argc, char *argv[]){
  const double input = (argc>1 && argv[1])? atof(argv[1]) : 1.0;

  printf("log2(%g)\n",input); //fflush(stdout);

  const double out  = log2(input);
  const double diff = input-exp2(out);

  printf("log2(%g) %g\n",input,out); fflush(stdout);
  printf("is %f exp2 %g diff %g\n",out, exp2(out), diff);
  /*ok if out is not close to zero*/
  const double smaller = out/(1+DBL_EPSILON);
  const double larger  = out*(1+DBL_EPSILON);

  const double d_smaller = input-exp2(smaller);
  const double d_larger  = input-exp2(larger);


  printf("smaller %f exp2 %g diff %g\n",
	 smaller, exp2(smaller), d_smaller);
  printf("larger  %f exp2 %g diff %g\n",
	 larger,  exp2(larger),  d_larger);

  if(fabs(d_smaller)<fabs(diff)){printf("SMALLER CLOSER\n");return EXIT_FAILURE;}
  if(fabs(d_larger) <fabs(diff)){printf("LARGER  CLOSER\n");return EXIT_FAILURE;}

  return EXIT_SUCCESS;
}
