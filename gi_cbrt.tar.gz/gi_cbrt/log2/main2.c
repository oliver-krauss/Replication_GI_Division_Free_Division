/*WBL 19 May 2018 based on main.c r1.8  */
#define Version "$Revision: 1.2 $"

/*WBL 10 Jun 2018 update ../sqrt/main2.c r1.7 for log2
 */

//Compile.bat

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
//#include <ctype.h>
//#include <unistd.h>
#include <string.h>

#include "t_log2.c"
//#include "t_cbrt.c"
//#include "e_sqrt.c"

int t_log2_idx; //not in use but keep linker happy
double input;   //not in use but keep linker happy

double neighbour(const double x, const int dir);
double read_double(const char* text);
void print_double(const double x);
double tweak_double(const double x, const int epsilon);
//double table_ieee754_log2 (double x);
double gi_log2 (const double x);

void print2(const char* text, const double out, const double diff) {
  printf("%s",text);
  print_double(out);
  printf(" exp2 ");
  const double inv = exp2(out);
  print_double(inv);
  printf(" diff %g\n",diff);
}

int main(int argc, char *argv[]){
  printf("%s %s argc %d %s\n",__FILE__,Version,argc,(argc>1)? argv[1]:"\"\"");
  const double input = (argc>1 && argv[1][0])? 
    ((strncmp(argv[1],"0x",2)==0)? read_double(argv[1]) : atof(argv[1])) : 1.0;

  printf("gi_log2 ");print_double(input);printf("\n");

  const double out  = gi_log2(input);
  const double diff = input-exp2(out);

  printf("gi_log2(%g) ",input);
  print2("is ",out,diff);

  const double n0 = neighbour(out,0);
  const double n1 = neighbour(out,1);

  const double d_n0 = input-exp2(n0);
  const double d_n1 = input-exp2(n1);

  print2("n0 ",n0,d_n0);
  print2("n1 ",n1,d_n1);

  double error = DBL_MAX; int I; double best;
  for(int i=-9;i<=9;i++){
    const double test   = tweak_double(out,i);
    const double d_test = input-exp2(test);
    printf("test %2d ",i);
    print2("",test,d_test);
    if((fabs(d_test)<error) || (fabs(d_test)==error && abs(i)<abs(I))){
      error=fabs(d_test); I=i; best=test;
    }
  }
  printf("Best local estimate %d ",I);
  print2("",best,error);
  if(I>= -1 && I<= 1) return EXIT_SUCCESS;

  if(fabs(d_n0)<fabs(diff)){printf("n0 CLOSER\n");return EXIT_FAILURE;}
  if(fabs(d_n1)<fabs(diff)){printf("n1 CLOSER\n");return EXIT_FAILURE;}

  return EXIT_SUCCESS;
}
