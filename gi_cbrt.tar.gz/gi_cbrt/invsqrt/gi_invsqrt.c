/* WBL 3 March 2019 $Revision: 1.22 $
based on gi_cbrt.c r1.20 and e_sqrt.c r1.9
glibc-2.29/sysdeps/powerpc/fpu/e_sqrt.c as 2.27 except #include <fenv.h>
*/
/* Double-precision floating point square root.
   Copyright (C) 1997-2018 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */

/*Modifications:
WBL  9 Mar 2019 Back to r1.9 make sure loglike returns 0 only if diff is 0
WBL  6 Mar 2019 Remove much debug before trying CMA-ES
WBL  4 Mar 2019 Convert for use as GI version of inverse square root
           based on glibc-2.29/sysdeps/powerpc/fpu/e_sqrt.c with e_sqrt.c r1.9
	   for invsqrt no need to divide in Newton-Raphson so can avoid sy
WBL 26 Jun 2018 For release kit, consolidate different versions
WBL 21 May 2018 Reverted back to r1.10 for testing mode,
           add read_double,print_double,tweak_double
WBL 18 May 2018 hack from sqrt to cbrt
 */

#ifndef NDEBUG
#include <stdio.h>
#include <assert.h>
#include <float.h>
#endif

#include <math.h>
#include <math_private.h>
#include <fenv.h>
//#include <fenv_libc.h> powerpc specific
#include <inttypes.h>
#include <stdint.h>
#include <sysdep.h>
#include <ldsodefs.h>

#define reverse(x) (1.0/(x*x))

double table_ieee754_invsqrt (double x);
/*for CMA-ES*/
/* the objective (fitness) function to be minimized */
/* Try 3 fitness cases */
double test(const double input) {  /*based on main2.c 1.3*/
  printf("table_ieee754_invsqrt(%0.17f) ",input); fflush(stdout);
  const double out  = table_ieee754_invsqrt(input);
  /*Penalise negative solutions */
  const double diff = (out<0)? input + reverse(out) : input - reverse(out);

  printf("is %0.17f recipricol square %g diff %g\n",out, reverse(out), diff);

  if(fabs(diff) > 1e-14) return fabs(diff);

  const double smaller = out/(1+DBL_EPSILON);
  const double larger  = out*(1+DBL_EPSILON);

  const double d_smaller = input-reverse(smaller);
  const double d_larger  = input-reverse(larger);


  printf("smaller %0.17f reverse %g diff %g\n",
	 smaller, reverse(smaller), d_smaller);
  printf("larger  %0.17f reverse %g diff %g\n",
	 larger,  reverse(larger),  d_larger);

 if( fabs(diff) <= 2*DBL_EPSILON &&
   ((d_smaller <= 0 && d_larger >= 0) || (d_smaller >= 0 && d_larger <= 0))){
    if(d_smaller <= diff && diff <= d_larger) return 0.0;
    if(d_smaller >= diff && diff >= d_larger) return 0.0;
    return fabs(diff);
  } else {
    if(fabs(d_smaller)<fabs(diff)) return fabs(diff);
    if(fabs(d_larger) <fabs(diff)) return fabs(diff);
    return 0.0;
  }
}

//hmm perhaps CMA_ES not good with tiny values, try log
double loglike(const double diff) {
  const double loglike_smallest = 1.0-log(DBL_EPSILON);
  assert(diff>=0);
  if(diff==0.0) return diff;
  if(diff< 1.0) return loglike_smallest+log(diff);
  return loglike_smallest+diff;
}

float __t_cbrt[512];
extern const double input;
extern const double cheat; /* 1/sqrt(input); avoid linking with glibc-2.29 */
uint32_t table_cbrt_idx(const double x);
double fitfun(double const *x, const int N) {
  assert(N==1);
  const uint32_t t_cbrt_idx = table_cbrt_idx(input);
  assert(t_cbrt_idx >= 0);
  assert(t_cbrt_idx < 512);

  memset(__t_cbrt,0,512*sizeof(float)); /*Ensure correct use of __t_cbrt*/
  __t_cbrt[t_cbrt_idx] = (float) x[0];
  //__t_cbrt[t_cbrt_idx+1] = (float) x[1];

  double diff[3];
  double sum = 0;
  ieee_double_shape_type ew_u;
  ew_u.value = input;
  //printf("input ew_u 0x%08x,%08x\n",ew_u.parts.msw,ew_u.parts.lsw);
  //For invsqrt (like sqrt) use top 8 bits of fraction and least sig bit of exponent

  ew_u.parts.msw = ew_u.parts.msw & 0xfffff000; //clear all of lower fraction part
  ew_u.parts.lsw = 0;
  //printf("lowpoint ew_u 0x%08x,%08x %0.17f\n",ew_u.parts.msw,ew_u.parts.lsw,ew_u.value);
  diff[0] = test(ew_u.value);

  ew_u.parts.msw = ew_u.parts.msw | 0x00000800; //set mid bit only
  //printf("midpoint ew_u 0x%08x,%08x %0.17f\n",ew_u.parts.msw,ew_u.parts.lsw,ew_u.value);
  diff[1] = test(ew_u.value);

  ew_u.parts.msw = ew_u.parts.msw | 0x00000fff; //set all lower fraction part
  ew_u.parts.lsw = 0xffffffff;
  //printf("toppoint ew_u 0x%08x,%08x %0.17f\n",ew_u.parts.msw,ew_u.parts.lsw,ew_u.value);
  diff[2] = test(ew_u.value);

  for(int i=0;i<3;i++) {
    const double ldif = loglike(diff[i]);
    sum += ldif;
    assert(ldif>=0);
    assert((diff[i]==0 && ldif==0) || (diff[i]>0 && ldif>0));
    assert(sum>=0);
    assert(sum>=ldif);
  }
  printf("fitfun %0.17f %0.17f %g %g ",
	 x[0],__t_cbrt[t_cbrt_idx],x[0]-__t_cbrt[t_cbrt_idx],sum);
  for(int i=0;i<3;i++) {
    const double ldif = loglike(diff[i]);
    printf("diff[%d] %g ldif %g ",i,diff[i],ldif);
  }
  printf("\n");

  if(sum==0) printf("DONE t_cbrt_idx %d %0.17f\n",t_cbrt_idx,__t_cbrt[t_cbrt_idx]);

  return sum;
}

uint32_t table_cbrt_idx(const double x){
  ieee_double_shape_type ew_u;
  ew_u.value = (x);
  const uint32_t xi0 = ew_u.parts.msw;
  return (xi0 >> (52 - 32 - 8 - 1) & 0x3fe)/2;
}

#ifndef _ARCH_PPCSQ

/*glibc-2.27/sysdeps/ieee754/dbl-64/s_cbrt.c */
#define CBRT2 1.2599210498948731648		/* 2^(1/3) */
#define SQR_CBRT2 1.5874010519681994748		/* 2^(2/3) */

//#define __builtin_fma(a, b, c) (((a)*(b))+(c))
//__builtin_fma really just a placeholder so easy to see code changes
#define __builtin_fma(a, c) ((a)+(c))

/* from sysdeps/powerpc/fpu/fenv_libc.h, ie powerpc specific
This operation (i) sets the appropriate FPSCR bits for its
   parameter, (ii) converts sNaN to the corresponding qNaN, and (iii)
   otherwise passes its parameter through unchanged (in particular, -0
   and +0 stay as they were).  The `obvious' way to do this is optimised
   out by gcc.
#define f_wash(x) \
   ({ double d; asm volatile ("fmul %0,%1,%2" \
			      : "=f"(d) \
			      : "f" (x), "f"((float)1.0)); d; })
*/
#define f_wash(x) (x)

double read_double(const char* text){
  ieee_double_shape_type ew_u;
  const int check = sscanf(text,"%x,%x",&ew_u.parts.msw,&ew_u.parts.lsw);
  assert(check==2);
  return ew_u.value;
}

void print_double(const double x){
  ieee_double_shape_type ew_u;
  ew_u.value = x;
  printf("%g 0x%08x,%08x",x,ew_u.parts.msw,ew_u.parts.lsw);
}

double tweak_double(const double x, const int epsilon){
  ieee_double_shape_type ew_u;
  ew_u.value = x;
  long unsigned int temp = ew_u.parts.lsw + epsilon;
  if(temp > 0xffffffff) {
    fprintf(stderr,"tweak_double(%g,%d) overflowed lsw 0x%lx\n",x,epsilon,temp);}
  ew_u.parts.lsw = temp;
  return ew_u.value;
}

//static const double almost_half = 0.5000000000000001;	/* 0.5 + 2^-53 */
//static const double almost_third = 0.3333333333333334;/* 1/3 + 2^-53 */
static const ieee_float_shape_type a_nan = {.word = 0x7fc00000 };
static const ieee_float_shape_type a_inf = {.word = 0x7f800000 };
static const float two108 = 3.245185536584267269e+32;
//static const float twom54 = 5.551115123125782702e-17;
static const float two54 = 18014398509481984.0;
//extern const float __t_sqrt[1024];

/* WBL do not worry about speed, see if can get table approach to work! 
   treat comments with caution many are from powerpc sqrt

   The method is based on a description in
   Computation of elementary functions on the IBM RISC System/6000 processor,
   P. W. Markstein, IBM J. Res. Develop, 34(1) 1990.
   Basically, it consists of two interleaved Newton-Raphson approximations,
   one to find the actual square root, and one to find its reciprocal
   without the expense of a division operation.   The tricky bit here
   is the use of the POWER/PowerPC multiply-add operation to get the
   required accuracy with high speed.

   The argument reduction works by a combination of table lookup to
   obtain the initial guesses, and some careful modification of the
   generated guesses (which mostly runs on the integer unit, while the
   Newton-Raphson is running on the FPU).  */

//WBL 3 March 2019 Replace table driven cbrt by table driven invsqrt based on e_sqrt.c's __slow_ieee754_sqrt
double table_ieee754_invsqrt (const double x)
{
#ifndef NDEBUG
{
  printf("table_ieee754_invsqrt (%0.21f ",x);
  print_double(x);
  printf(")\n");
}
#endif

  const float inf = a_inf.value;

  if (x > 0)
    {
      /* schedule the EXTRACT_WORDS to get separation between the store
	 and the load.  */
      ieee_double_shape_type ew_u;
      ieee_double_shape_type iw_u;
      ew_u.value = (x);
      if (x != inf)
	{
	  /* Variables named starting with 's' exist in the
	     argument-reduced space, so that 2 > sx >= 0.5,
	     1.41... > sg >= 0.70.., 0.70.. >= sy > 0.35... .
	     Variables named ending with 'i' are integer versions of
	     floating-point values.  */
	  double sx;	/* The value of which we're trying to find the
			   square root.  */
	  double sg, g;	/* Guess of the square root of x.  */
	  double sd;/*d; * Difference between the square of the guess and x.  */
	  //double sy;	/* Estimate of 1/2g (overestimated by 1ulp).  */
	  //double sy2;	/* 2*sy */
	  //double e;	/* Difference between y*g and 1/2 (se = e * fsy).  */
	  double shx;	/* == sx * fsg */
	  double fsg;	/* sg*fsg == g.  */
	  /* fenv_t fe;	   Saved floating-point environment (stores rounding
			   mode and whether the inexact exception is
			   enabled).  */
	  uint32_t xi0, xi1, sxi, fsgi;
	  //const float *t_sqrt;

	  //fe = fegetenv_register ();
	  /* complete the EXTRACT_WORDS (xi0,xi1,x) operation.  */
	  xi0 = ew_u.parts.msw;
	  xi1 = ew_u.parts.lsw;
	  //relax_fenv_state ();
	  sxi = (xi0 & 0x3fffffff) | 0x3fe00000;
	  /* schedule the INSERT_WORDS (sx, sxi, xi1) to get separation
	     between the store and the load.  */
	  iw_u.parts.msw = sxi;
	  iw_u.parts.lsw = xi1;
	  const int idx = (xi0 >> (52 - 32 - 8 - 1) & 0x3fe)/2;
	  assert(idx >= 0);
	  assert(idx < 512);
	  sg = __t_cbrt[idx];
	  //sy = t_sqrt[1];
	  //printf("Table values %g %g\n",sg);
	  //assert(sg==sg_);
	  /* complete the INSERT_WORDS (sx, sxi, xi1) operation.  */
	  sx = iw_u.value;

	  /*confusing as hell: try x1, x2 and x3 */
	  /*To start with assume we are dealing only with normalised numbers **
	  assert(sx>=0.5 && sx <2);
	  const double x0 = sg;
	  const double d0 = (x0 - x0*x0*x0*sx)/2;
	  const double x1 = x0 + d0;
	  const double d1 = (x1 - x1*x1*x1*sx)/2;
	  const double x2 = x1 + d1;
	  const double d2 = (x2 - x2*x2*x2*sx)/2;
	  const double x3 = x2 + d2;


	  printf("x0 %g, x1 %g, x2 %g, x3 %g\n",x0,x1,x2,x3);
	  printf("d0 %g, %g, %g\n",d0,d1,d2);
	  printf("diffs %g, %g, %g, %g\n",cheat-x0,cheat-x1,cheat-x2,cheat-x3);

	  exit(0);
	  */
	  /* Here we have three Newton-Raphson iterations each of a
	     division and a square root and the remainder of the
	     argument reduction, all interleaved.   */
	  sd = __builtin_fma (sg, -sx*sg*sg*sg)/2;
	  printf("Normalised target %g initial error %g\n",sx,sd);
	  const uint32_t tmp = (xi0 + 0x40000000) >> 1 & 0x7ff00000;
	  fsgi = 0x7fe00000 - tmp; /*invert exponent*/

	  printf("xi0 0x%08x, sxi 0x%08x, __t_cbrt[%3d] %g, \n",
		         xi0,        sxi,          idx, sg);
	  printf("tmp 0x%08x, fsgi 0x%08x\n",
		  tmp,        fsgi);

	  //sy2 = sy + sy;
	  sg = __builtin_fma (sd, sg);	/* 16-bit approximation to
						   sqrt(sx). */

	  /* schedule the INSERT_WORDS (fsg, fsgi, 0) to get separation
	     between the store and the load.  */
	  INSERT_WORDS (fsg, fsgi, 0);
	  iw_u.parts.msw = fsgi;
	  iw_u.parts.lsw = (0);
	  //e = -__builtin_fma (sy, sg, -almost_half);
	  sd = __builtin_fma (sg, -sx*sg*sg*sg)/2;
	  printf("Second estimate %g 2nd error %g\n",sg,sd);
	  if ((xi0 & 0x7ff00000) == 0)
	    goto denorm;
	  //sy = __builtin_fma (e, sy2, sy);
	  sg = __builtin_fma (sd, sg);	/* 32-bit approximation to
						   sqrt(sx).  */
	  //sy2 = sy + sy;
	  /* complete the INSERT_WORDS (fsg, fsgi, 0) operation.  */
	  fsg = iw_u.value;
	  //e = -__builtin_fma (sy, sg, -almost_half);
	  sd = __builtin_fma (sg, -sx*sg*sg*sg)/2;
	  printf("3rd estimate %g 3rd error %g\n",sg,sd);
	  //sy = __builtin_fma (e, sy2, sy);
	  shx = sx * fsg;
	  sg = __builtin_fma (sd, sg);	/* 64-bit approximation to
						   sqrt(sx), but perhaps
						   rounded incorrectly.  */
	  printf("fsg %g last normalised estimate %g shx %g\n",fsg,sg,shx);

	  //sy2 = sy + sy;
	  g = sg * fsg;
	  //e = -__builtin_fma (sy, sg, -almost_half);
	  //do we need this? d = __builtin_fma (g, -shx);
	  //sy = __builtin_fma (e, sy2, sy);
	  //printf("shx %g last estimate %g error %g\n",shx,g,d);
	  //fesetenv_register (fe);
	  const double ans = g;//__builtin_fma (d, g);
	  //printf("table_ieee754_invsqrt(%g) returns %g\n",x,ans);
	  return ans;
	denorm:
	  //assert(0); //we are not seeing this...
	  /* For denormalised numbers, we normalise, calculate the
	     square root, and return an adjusted result.  */
	  //fesetenv_register (fe);
	  return table_ieee754_invsqrt (x * two108) * two54;
	}
    }
  else if (x < 0)
    {
      /* For some reason, some PowerPC32 processors don't implement
	 FE_INVALID_SQRT.  */
#ifdef FE_INVALID_SQRT
      __feraiseexcept (FE_INVALID_SQRT);

      fenv_union_t u = { .fenv = fegetenv_register () };
      if ((u.l & FE_INVALID) == 0)
#endif
	__feraiseexcept (FE_INVALID);
      return a_nan.value;
    }
  return f_wash (x);
}
#endif /* _ARCH_PPCSQ  */
