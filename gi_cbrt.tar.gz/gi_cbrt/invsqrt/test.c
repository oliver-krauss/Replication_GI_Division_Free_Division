/* WBL 19 May 2018 based on example_short.c */
#define Version "$Revision: 1.9 $"

#include <stdio.h>
#include <stdlib.h> /* free() */
#include <stddef.h> /* NULL */
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <float.h>
#include <assert.h>

double input;
double cheat; ; /* 1/sqrt(input); something up linking glibc-2.29 :-( */
double fitfun(double const *x, const int dim); 

/* the optimization loop */
int main(int argc, char *argv[]) {
  int i,I=0;
  printf("%s %s ",__FILE__,Version); fflush(stdout);
  double initialX[1] = {0.0};

  I++;
  input = (argc>I && argv[I][0])? atof(argv[I]): 1.0;
  cheat = 1/sqrt(input);
  /*const uint32_t t_cbrt_idx = table_cbrt_idx(input);
  assert(t_cbrt_idx < 512);*/

  I++;
  if(argc>I) {
    initialX[0] = atof(argv[I]);
  } else if(argc>I) {fprintf(stderr,"Bad command line %d %s\n",argc,argv[I]); exit(2);}

  printf("%0.17f %0.17f initialX[0] %g\n",input,cheat,initialX[0]);
  printf("argc %d ",argc);
  for(i=1;i<argc;i++) printf("%s ",(argv[i][0])? argv[i] : "\"\"");
  printf("\n");

  fitfun(initialX, 1);

  return 0;
}

