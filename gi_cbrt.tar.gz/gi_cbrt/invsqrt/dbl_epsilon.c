/* WBL 14 March 2019 $Revision: 1.00 $ */

/*Modifications:
 */

#include <stdio.h>
//#include <assert.h>

#include <float.h>
//#include <math.h>
//#include <math_private.h>
//#include <fenv_libc.h> powerpc specific
//#include <inttypes.h>
//#include <stdint.h>
//#include <sysdep.h>
//#include <ldsodefs.h>

int main() {
  printf("DBL_EPSILON %g\n",DBL_EPSILON); //DBL_EPSILON 2.22045e-16
  return 0;
}
