/*WBL 19 May 2018 based on main.c r1.8  */
#define Version "$Revision: 1.3 $"

/*WBL 11 Mar 2019 update ../log2/main2.c r1.2 for invsqrt
 *WBL 10 Jun 2018 update ../sqrt/main2.c r1.7 for log2
 */

// compile.bat

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <math_private.h> /*from gi_log2.c*/
#include <float.h>
//#include <ctype.h>
//#include <unistd.h>
#include <string.h>

/*Can reuse log2 using:
gawk -f ../log2/make_t_log2.awk gi_t_invsqrt.out > t_invsqrt.c
but define kinda ugly */
#define __t_log2 __t_cbrt
#include "t_invsqrt.c"
//#include "t_log2.c"
//#include "t_cbrt.c"
//#include "e_sqrt.c"

//int t_log2_idx; //not in use but keep linker happy
double input;   //not in use but keep linker happy

double neighbour(const double x, const int dir);
double read_double(const char* text);
void print_double(const double x);
double tweak_double(const double x, const int epsilon);
/*taken from gi_log2.c r1.18 */
double neighbour(const double x, const int dir) {
  if(fabs(x)>1.0) return dir? x*(1+DBL_EPSILON) : x/(1+DBL_EPSILON);
  else            return x  + (dir? DBL_EPSILON : -DBL_EPSILON);
}
/*end gi_log2.c r1.18 */

//double table_ieee754_log2 (double x);
double table_ieee754_invsqrt(const double x);
double reverse(const double x){ return 1.0/(x*x);};

void print2(const char* text, const double out, const double diff) {
  printf("%s",text);
  print_double(out);
  printf(" reverse ");
  const double inv = reverse(out);
  print_double(inv);
  printf(" diff %g\n",diff);
}

int main(int argc, char *argv[]){
  printf("%s %s argc %d %s\n",__FILE__,Version,argc,(argc>1)? argv[1]:"\"\"");
  const double input = (argc>1 && argv[1][0])? 
    ((strncmp(argv[1],"0x",2)==0)? read_double(argv[1]) : atof(argv[1])) : 1.0;

  printf("invsqrt ");print_double(input);printf("\n");

  const double out  = table_ieee754_invsqrt(input);
  const double diff = input-reverse(out);

  printf("invsqrt(%g) ",input);
  print2("is ",out,diff);

  const double n0 = neighbour(out,0);
  const double n1 = neighbour(out,1);

  const double d_n0 = input-reverse(n0);
  const double d_n1 = input-reverse(n1);

  print2("n0 ",n0,d_n0);
  print2("n1 ",n1,d_n1);

  double error = DBL_MAX; int I=INT_MAX; double best = DBL_MAX;
  for(int i=-9;i<=9;i++){
    const double test   = tweak_double(out,i);
    const double d_test = input-reverse(test);
    printf("test %2d ",i);
    print2("",test,d_test);
    if((fabs(d_test)<error) || (fabs(d_test)==error && abs(i)<abs(I))){
      error=fabs(d_test); I=i; best=test;
    }
  }
  printf("Best local estimate %d ",I);
  print2("",best,error);
  if(I>= -1 && I<= 1) return EXIT_SUCCESS;

  if(fabs(d_n0)<fabs(diff)){printf("n0 CLOSER\n");return EXIT_FAILURE;}
  if(fabs(d_n1)<fabs(diff)){printf("n1 CLOSER\n");return EXIT_FAILURE;}

  return EXIT_SUCCESS;
}
