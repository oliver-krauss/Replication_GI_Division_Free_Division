/* WBL 11 March 2019 $Revision: 1.2 $
Stolen from 
https://stackoverflow.com/questions/268853/is-it-possible-to-write-quakes-fast-invsqrt-function-in-c
based on gi_invsqrt.c r1.21
*/
/*Modifications:
 */

#ifndef NDEBUG
#include <stdio.h>
#include <assert.h>
#include <float.h>
#endif

#include <math.h>
#include <math_private.h>
#include <fenv.h>
//#include <fenv_libc.h> powerpc specific
#include <inttypes.h>
#include <stdint.h>
#include <sysdep.h>
#include <ldsodefs.h>

#define reverse(x) (1.0/(x*x))

double table_ieee754_invsqrt (double x);
/*for CMA-ES*/
/* the objective (fitness) function to be minimized */
/* Try 3 fitness cases */
double test(const double input) {  /*based on main2.c 1.3*/
  printf("table_ieee754_invsqrt(%0.17f) ",input); fflush(stdout);
  const double out  = table_ieee754_invsqrt(input);
  /*Penalise negative solutions */
  const double diff = (out<0)? input + reverse(out) : input - reverse(out);

  printf("is %0.17f recipricol square %g diff %g\n",out, reverse(out), diff);

  if(fabs(diff) > 1e-14) return fabs(diff);

  const double smaller = out/(1+DBL_EPSILON);
  const double larger  = out*(1+DBL_EPSILON);

  const double d_smaller = input-reverse(smaller);
  const double d_larger  = input-reverse(larger);


  printf("smaller %0.17f reverse %g diff %g\n",
	 smaller, reverse(smaller), d_smaller);
  printf("larger  %0.17f reverse %g diff %g\n",
	 larger,  reverse(larger),  d_larger);

 if( fabs(diff) <= 2*DBL_EPSILON &&
   ((d_smaller <= 0 && d_larger >= 0) || (d_smaller >= 0 && d_larger <= 0))){
    if(d_smaller <= diff && diff <= d_larger) return 0.0;
    if(d_smaller >= diff && diff >= d_larger) return 0.0;
    return fabs(diff);
  } else {
    if(fabs(d_smaller)<fabs(diff)) return fabs(diff);
    if(fabs(d_larger) <fabs(diff)) return fabs(diff);
    return 0.0;
  }
}

//hmm perhaps CMA_ES not good with tiny values, try log
double loglike(const double diff) {
  const double loglike_smallest = 1.0-log(DBL_EPSILON);
  assert(diff>=0);
  if(diff==0.0) return diff;
  if(diff< 1.0) return loglike_smallest+log(diff);
  return loglike_smallest+diff;
}

float __t_cbrt[512];
extern const double input;
extern const double cheat; /* 1/sqrt(input); avoid linking with glibc-2.29 */
uint32_t table_cbrt_idx(const double x);
double fitfun(double const *x, const int N) {
  assert(N==1);
  const uint32_t t_cbrt_idx = table_cbrt_idx(input);
  assert(t_cbrt_idx >= 0);
  assert(t_cbrt_idx < 512);

  memset(__t_cbrt,0,512*sizeof(float)); /*Ensure correct use of __t_cbrt*/
  __t_cbrt[t_cbrt_idx] = (float) x[0];
  //__t_cbrt[t_cbrt_idx+1] = (float) x[1];

  double diff[3];
  double sum = 0;
  ieee_double_shape_type ew_u;
  ew_u.value = input;
  //printf("input ew_u 0x%08x,%08x\n",ew_u.parts.msw,ew_u.parts.lsw);
  //For invsqrt (like sqrt) use top 8 bits of fraction and least sig bit of exponent

  ew_u.parts.msw = ew_u.parts.msw & 0xfffff000; //clear all of lower fraction part
  ew_u.parts.lsw = 0;
  //printf("lowpoint ew_u 0x%08x,%08x %0.17f\n",ew_u.parts.msw,ew_u.parts.lsw,ew_u.value);
  diff[0] = test(ew_u.value);

  ew_u.parts.msw = ew_u.parts.msw | 0x00000800; //set mid bit only
  //printf("midpoint ew_u 0x%08x,%08x %0.17f\n",ew_u.parts.msw,ew_u.parts.lsw,ew_u.value);
  diff[1] = test(ew_u.value);

  ew_u.parts.msw = ew_u.parts.msw | 0x00000fff; //set all lower fraction part
  ew_u.parts.lsw = 0xffffffff;
  //printf("toppoint ew_u 0x%08x,%08x %0.17f\n",ew_u.parts.msw,ew_u.parts.lsw,ew_u.value);
  diff[2] = test(ew_u.value);

  for(int i=0;i<3;i++) {
    const double ldif = loglike(diff[i]);
    sum += ldif;
    assert(ldif>=0);
    assert((diff[i]==0 && ldif==0) || (diff[i]>0 && ldif>0));
    assert(sum>=0);
    assert(sum>=ldif);
  }
  printf("fitfun %0.17f %0.17f %g %g ",
	 x[0],__t_cbrt[t_cbrt_idx],x[0]-__t_cbrt[t_cbrt_idx],sum);
  for(int i=0;i<3;i++) {
    const double ldif = loglike(diff[i]);
    printf("diff[%d] %g ldif %g ",i,diff[i],ldif);
  }
  printf("\n");

  if(sum==0) printf("DONE t_cbrt_idx %d %0.17f\n",t_cbrt_idx,__t_cbrt[t_cbrt_idx]);

  return sum;
}

uint32_t table_cbrt_idx(const double x){
  ieee_double_shape_type ew_u;
  ew_u.value = (x);
  const uint32_t xi0 = ew_u.parts.msw;
  return (xi0 >> (52 - 32 - 8 - 1) & 0x3fe)/2;
}

double read_double(const char* text){
  ieee_double_shape_type ew_u;
  const int check = sscanf(text,"%x,%x",&ew_u.parts.msw,&ew_u.parts.lsw);
  assert(check==2);
  return ew_u.value;
}

void print_double(const double x){
  ieee_double_shape_type ew_u;
  ew_u.value = x;
  printf("%g 0x%08x,%08x",x,ew_u.parts.msw,ew_u.parts.lsw);
}

double tweak_double(const double x, const int epsilon){
  ieee_double_shape_type ew_u;
  ew_u.value = x;
  long unsigned int temp = ew_u.parts.lsw + epsilon;
  if(temp > 0xffffffff) {
    fprintf(stderr,"tweak_double(%g,%d) overflowed lsw 0x%lx\n",x,epsilon,temp);}
  ew_u.parts.lsw = temp;
  return ew_u.value;
}


//Is it possible to write Quake's fast InvSqrt() function in C#?
//Also https://en.wikipedia.org/wiki/Fast_inverse_square_root float Q_rsqrt
float InvSqrt (float x)
{
   float xhalf = 0.5f*x;
   int i = *(int*)&x;
   i = 0x5f3759df - (i>>1);
   x = *(float*)&i;
   x = x*(1.5f - xhalf*x*x);
   return x;
}

double table_ieee754_invsqrt (const double x)
{
  const float y = x;
  return InvSqrt(y);
}
