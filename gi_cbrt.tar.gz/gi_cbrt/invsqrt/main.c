/*WBL 17 May 2018 "$Revision: 1.5 $" */

//WBL 10 Mar 2019 Report relative error rather than stoping test.bat
//WBL  9 Mar 2019 for use with newly created t_invsqrt.c
//WBL  8 Jun 2018 for use with newly created t_log2.c
//WBL 26 May 2018 for use with log2

//Compile: gcc -c main.c; gcc -o main gi_invsqrt.o main.o -lm
//Use:     ../sqrt/test.bat >& gi_invsqr_test.out

//#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
//#include <ctype.h>
//#include <unistd.h>
//#include <string.h>

/*Can reuse log2 using:
gawk -f ../log2/make_t_log2.awk gi_t_invsqrt.out > t_invsqrt.c
but define kinda ugly */
#define __t_log2 __t_cbrt
#include "t_invsqrt.c"
//#include "t_test.c"
//#include "e_sqrt.c"

//int t_log2_idx; //not in use but keep linker happy

//#define sqrt __ieee754_sqrt
//double __ieee754_sqrt (const double x);
//double table_ieee754_log2 (const double x);
double table_ieee754_invsqrt(const double x);
double reverse(const double x){ return 1.0/(x*x);};

double input;


int main(int argc, char *argv[]){
  const double input = (argc>1 && argv[1])? atof(argv[1]) : 1.0;

  printf("invsqrt(%g)\n",input); //fflush(stdout);

  const double out  = table_ieee754_invsqrt(input);
  const double diff = input-reverse(out);

  printf("invsqrt(%g) %g\n",input,out); fflush(stdout);
  printf("is %f x**-2 %g diff %g\n",out, reverse(out), diff);
  /*ok if out is not close to zero*/
  const double smaller = out/(1+DBL_EPSILON);
  const double larger  = out*(1+DBL_EPSILON);

  const double d_smaller = input-reverse(smaller);
  const double d_larger  = input-reverse(larger);


  printf("smaller %f x**-2 %g diff %g\n",
	 smaller, reverse(smaller), d_smaller);
  printf("larger  %f x**-2 %g diff %g\n",
	 larger,  reverse(larger),  d_larger);

  if(fabs(diff) > 1e-14 * fabs(input)) return EXIT_FAILURE;

  const double error = 1 - out*sqrt(input);
  printf("Relative error %g\n",error);

  if((d_smaller <= 0 && d_larger >= 0) || (d_smaller >= 0 && d_larger <= 0)){
    if(d_smaller <= diff && diff <= d_larger) return EXIT_SUCCESS;
    if(d_smaller >= diff && diff >= d_larger) return EXIT_SUCCESS;
    return EXIT_SUCCESS;
  }
  if(fabs(d_smaller)<fabs(diff)){printf("SMALLER CLOSER\n");return EXIT_SUCCESS;}
  if(fabs(d_larger) <fabs(diff)){printf("LARGER  CLOSER\n");return EXIT_SUCCESS;}

  return EXIT_SUCCESS;
}
