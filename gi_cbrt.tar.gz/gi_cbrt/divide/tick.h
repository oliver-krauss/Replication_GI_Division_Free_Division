// tick.h interface to tick level time.h routines
// W. Langdon cs.ucl.ac.uk 14 Feb 2017 "$Revision: 1.1 $"

#include <inttypes.h>
typedef int64_t int64;
int64 getTickCount(void);
