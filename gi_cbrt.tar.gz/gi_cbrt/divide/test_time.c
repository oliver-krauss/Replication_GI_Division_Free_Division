// See howlong conventional and GI dividion take
// W. Langdon cs.ucl.ac.uk 29 Apr 2019 based upon test_md.c r1.40
#ifdef TABLE
#define main_version "$Revision: 1.11 $ x*table_ieee754_inv(y)"
double input;   //not in use but keep linker happy
double table_ieee754_inv (double x);
/*Can reuse log2 using:
gawk -f ../log2/make_t_log2.awk gi_t_invsqrt.out > t_invsqrt.c
but define kinda ugly */
#define __t_log2 __t_cbrt
#include "t_invsqrt.c"
#else
#ifdef MUL
#define main_version "$Revision: 1.11 $ *"
#else
#define main_version "$Revision: 1.11 $ /"
#endif
#endif

//compile_test_time_inline.bat
//Compile gcc -O2 -DNDEBUG -DTABLE=1 test_time.c tick.o gi_inv.o -lm
//Compile gcc -O2 -DNDEBUG -DMUL=1 test_time.c tick.c  -lm
//Compile gcc -O2 -DNDEBUG -DMUL=1 test_time.c tick.c 

//Modifications (in reverse order)
//WBL  2 May 2019 try with table_ieee754_inv
//WBL 29 Apr 2019 start

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <math.h>
#include <float.h>
//#include <limits.h>
#include "tick.h"

//#include <string.h>

#ifdef TABLE
#include "dummy_inv.c"
//#include "gi_inv.c"
#endif

int todo;
int ntests;
double* tests = NULL;

void similar(const double k, const double j, const double i){
#ifdef TABLE
  const double ans = j/i;
  const double r   = k/ans;
  if(((isnan(r) && (!isinf(k)) && (k > 1e-100 || k < -1e100))) || r<(1-2*DBL_EPSILON) || r >(1+2*DBL_EPSILON)) {
    fprintf(stderr,"not similar(%g,%g,%g) %g r=%g\n",
	    k,j,i,ans,r);
    //exit(1);
  }
#endif
}

inline void test8() {
  int i,j,k,L;
  for(L=0;L<todo;)
  for(i=0,j=ntests,k=j+ntests;i<ntests && L<todo;i+=8,j+=8,k+=8,L+=8){
    //const double ans = 1.0/2;
    //assert(ans==0.5);
    //const double ans = 1.0*0.5;
#ifdef TABLE
#define OP(x,y) x*table_ieee754_inv(y)
#else
#ifdef MUL
#define OP(x,y) x*y
#else
#define OP(x,y) x/y
#endif
#endif
    tests[k+0] = OP(tests[j+0],tests[i+0]);
    tests[k+1] = OP(tests[j+1],tests[i+1]);
    tests[k+2] = OP(tests[j+2],tests[i+2]);
    tests[k+3] = OP(tests[j+3],tests[i+3]);
    tests[k+4] = OP(tests[j+4],tests[i+4]);
    tests[k+5] = OP(tests[j+5],tests[i+5]);
    tests[k+6] = OP(tests[j+6],tests[i+6]);
    tests[k+7] = OP(tests[j+7],tests[i+7]);
    //printf("%10d %g/%g %g\n",i,tests[j],tests[i],tests[k]);
    assert(!isnan(tests[k]));
#ifndef NDEBUG
    similar(tests[k],tests[j],tests[i]);
#endif
    //assert(!isinf(tests[k]));
  }
}

long long int do_test() {
  const long long int t0 = getTickCount();
  test8();
  const long long int t1 = getTickCount();
  const long long int fitness_time = t1 - t0;
  return fitness_time;
}

//unsigned time(void* x){return 0;} //keep gcc version 7.3.1 happy
int gpquick_seed;
#include "pch.h"

double g_rand() {
  char buf[80];
  char* p = buf;
  *p = (rnd(2)==0)? '-' : ' ';        p++;
  sprintf(p,"%019.17f",drand_0to1()); p+=19;
  *p = 'e';                           p++;
  *p = (rnd(2)==0)? '-' : '+';        p++;
  sprintf(p,"%03d",rnd(308));
  const double ans = atof(buf);    
  //printf("buf '%s' %g\n",buf,ans);
  return ans;
}

#define up8(x) (((x+7)/8)*8)

int main(int argc, char * argv[]) {
  fprintf(stdout,"%s ", main_version);
  int i;
  todo             = (argc>1)? up8(atoi(argv[1])) : 1; 
  ntests           = (argc>2)? up8(atoi(argv[2])) : 64/sizeof(double); 
  const int seed = (argc>3)? atoi(argv[3]) : 145020;
  for(i=0;i<argc;i++) fprintf(stdout,"%s ",argv[i]);
  fflush(stdout);

  gpquick_seed  = seed;
  tests = aligned_alloc(64,3*ntests*sizeof(double)); //x86 cache line size=64bytes
  if(tests==NULL) {
    fprintf(stdout,"aligned_alloc(64,%ld) failed %d\n",3*ntests*sizeof(double), errno);
    return 1;
  }
  //tests = calloc(ntests,sizeof(double));
  for(i=0;i<2*ntests;i++) {
    //tests[i] = drand_0to1();
    tests[i] = g_rand();
  }
  fprintf(stdout,"ntests %d seed %d ",ntests,seed);
  fflush(stdout);
  const long long int t = do_test();
  fprintf(stdout,"ran %d duration %llu %g seconds\n",todo,t,1.0e-9*(double)t);
  return 0;
}
